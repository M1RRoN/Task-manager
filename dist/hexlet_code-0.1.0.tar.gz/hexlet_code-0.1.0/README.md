### Hexlet tests and linter status:
[![Actions Status](https://github.com/M1RRoN/python-project-52/workflows/hexlet-check/badge.svg)](https://github.com/M1RRoN/python-project-52/actions)