# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['task_manager',
 'task_manager.fixtures',
 'task_manager.labels',
 'task_manager.labels.migrations',
 'task_manager.main',
 'task_manager.main.migrations',
 'task_manager.statuses',
 'task_manager.statuses.migrations',
 'task_manager.task_manager',
 'task_manager.tasks',
 'task_manager.tasks.migrations',
 'task_manager.users',
 'task_manager.users.migrations']

package_data = \
{'': ['*'],
 'task_manager': ['locale/en_us/LC_MESSAGES/*',
                  'staticfiles/admin/css/*',
                  'staticfiles/admin/css/vendor/select2/*',
                  'staticfiles/admin/fonts/*',
                  'staticfiles/admin/img/*',
                  'staticfiles/admin/img/gis/*',
                  'staticfiles/admin/js/*',
                  'staticfiles/admin/js/admin/*',
                  'staticfiles/admin/js/vendor/jquery/*',
                  'staticfiles/admin/js/vendor/select2/*',
                  'staticfiles/admin/js/vendor/select2/i18n/*',
                  'staticfiles/admin/js/vendor/xregexp/*',
                  'staticfiles/rest_framework/css/*',
                  'staticfiles/rest_framework/docs/css/*',
                  'staticfiles/rest_framework/docs/img/*',
                  'staticfiles/rest_framework/docs/js/*',
                  'staticfiles/rest_framework/fonts/*',
                  'staticfiles/rest_framework/img/*',
                  'staticfiles/rest_framework/js/*',
                  'templates/*',
                  'templates/labels/*',
                  'templates/statuses/*',
                  'templates/task_manager/*',
                  'templates/tasks/*',
                  'templates/users/*'],
 'task_manager.tasks': ['.pytest_cache/*', '.pytest_cache/v/cache/*']}

install_requires = \
['django>=4.1.4,<5.0.0',
 'djangorestframework>=3.14.0,<4.0.0',
 'gunicorn>=20.1.0,<21.0.0',
 'psycopg2>=2.9.5,<3.0.0',
 'setuptools>=65.6.3,<66.0.0']

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/M1RRoN/python-project-52/workflows/hexlet-check/badge.svg)](https://github.com/M1RRoN/python-project-52/actions)',
    'author': 'M1RRoN',
    'author_email': 'mds.myst@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
